# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['eseven', 'eseven.migrations']

package_data = \
{'': ['*'], 'eseven': ['static/styles/*', 'templates/*']}

install_requires = \
['Django>=3.2.9,<4.0.0',
 'Pillow>=8.4.0,<9.0.0',
 'dj-database-url>=0.5.0,<0.6.0',
 'django-heroku>=0.3.1,<0.4.0',
 'gunicorn>=20.1.0,<21.0.0',
 'psycopg2>=2.9.2,<3.0.0',
 'setuptools>=59.1.0,<60.0.0',
 'whitenoise>=5.3.0,<6.0.0']

setup_kwargs = {
    'name': 'eseven',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Your Name',
    'author_email': 'you@example.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
